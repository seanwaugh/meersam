#!/bin/sh
cd /opt/meersam/preprocessor
./preprocessor
