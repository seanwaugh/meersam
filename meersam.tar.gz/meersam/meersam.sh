#!/bin/sh
cd /opt/meersam/meersam
./meersam
